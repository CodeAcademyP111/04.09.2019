﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserSystemWb.Utilies
{
    public static class Utility
    {
        public enum Roles
        {
            Admin,
            Member
        }

        public const string AdminRole = "Admin";
        public const string MemberRole = "Member";
    }
}
